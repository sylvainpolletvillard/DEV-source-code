import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-tabs-page',
  templateUrl: './tabs-page.component.html',
  styleUrls: ['./tabs-page.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TabsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
