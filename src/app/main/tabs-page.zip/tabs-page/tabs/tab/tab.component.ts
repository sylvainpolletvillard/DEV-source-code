import { Component, OnInit, ViewEncapsulation, Input, AfterViewInit, ViewChildren, QueryList, ElementRef} from '@angular/core';
import { TabsComponent } from '../tabs.component';
import { AppComponent } from '../../../../app.component';

@Component({
  selector: 'app-tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TabComponent implements OnInit, AfterViewInit {

  @Input() tabTitle;
  @Input() isActive: boolean;
  @Input() idTab: number;
  tabID: string;
  panelID: string;

  @ViewChildren(TabComponent) childrenContent: QueryList<TabComponent>;

  constructor(tabs: TabsComponent, app: AppComponent) {
    tabs.addTab(this);
    this.idTab = app.randomID();
   }

  ngOnInit() {
    this.tabID = 'tab' + this.idTab;
    this.panelID = 'panel' + this.idTab;
  }

  ngAfterViewInit() {
    this.tabID = 'tab' + this.idTab;
    this.panelID = 'panel' + this.idTab;
    console.log(this.childrenContent);
  }


}
