import { Component, ViewEncapsulation, Input} from '@angular/core';
import { TabComponent } from './tab/tab.component';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TabsComponent {

  tabs: TabComponent[] = [];

  addTab(tab: TabComponent) {
    if (this.tabs.length === 0) {
      tab.isActive = true;
    }
    this.tabs.push(tab);
  }


  selectTab(tab: TabComponent) {
    this.tabs.forEach((TabComponent) => {
      TabComponent.isActive = false;
    });
    tab.isActive = true;
    }

  constructor() { }


  /* Je souhaite pouvoir récupérer le offset d'un tab.component (pour pouvoir gérer ajouter une classe si l'offsetTop du dernier tab est supérieur
   * à l'offsetTop du 1er tab, et ainsi passer tout les tab en display:block au lieu de inline-block) LE PROBLEME est que pour accéder aux tab, je dois
   * passer par mon composant tabs qui dispose d'un tableau de tab ( tabs: TabComponent[} = [] ) Donc j'arrive avec ElementRef et d'autre technique à récupérer
   * les @input ou variables globales de chaque tab mais pas de propriété du dom ni de style...     */
}
